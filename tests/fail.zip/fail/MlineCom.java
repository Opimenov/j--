//package fail;

//import java.lang.System;

// This program has lexical errors and shouldn't compile.

//public class MlineCom {
    //
//    this is not a multiline
//    */
    
//    /*  must fail */ */
//    /*  must fail //    
//    public static void main(String[] args) {
//        System.out.println("Hello, World!");
//    }

//}
