package fail;
import java.lang.System;
public class Modulo {
    public static void main(String[] args) {
	System.out.println('a' % 42);
	System.out.println(42 % 'a');
	System.out.println('c' % 'a');	
	System.out.println(42 % "String");
	System.out.println("String" % 42);
	System.out.println("String" % "String");
	System.out.println(true % 42);
	System.out.println(42 % true);
	System.out.println(true % true);
    }
}
