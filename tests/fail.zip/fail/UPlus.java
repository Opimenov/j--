package fail;
import java.lang.System;
public class UPlus {
    public static void main(String[] args) {
	char ch = 'c';
	char ch1 = +ch;
	System.out.println(+ch);
    }
}
