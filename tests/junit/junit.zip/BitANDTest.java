/*
package junit;

import junit.framework.TestCase;
import pass.BitAND;

public class BitANDTest extends TestCase {
    private BitAND b;
    
    protected void setUp() throws Exception {
        super.setUp();
	b = new BitAND();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testBitAND() {
        this.assertEquals(b.bitAND(0, 0), 0);
        this.assertEquals(b.bitAND(0, 1), 0);
        this.assertEquals(b.bitAND(1, 0), 0);
        this.assertEquals(b.bitAND(1, 1), 1);
    }

}
*/