/*
package junit;

import junit.framework.TestCase;
import pass.BitOR;

public class BitORTest extends TestCase {
    private BitOR bOR;
    
    protected void setUp() throws Exception {
        super.setUp();
	bOR = new BitOR();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testBitOR() {
        this.assertEquals(bOR.bitOR(0, 0), 0);
        this.assertEquals(bOR.bitOR(0, 1), 1);
        this.assertEquals(bOR.bitOR(1, 0), 1);
        this.assertEquals(bOR.bitOR(1, 1), 1);
    }

}
*/