/*
package junit;


import junit.framework.TestCase;
import pass.BitXOR;

public class BitXORTest extends TestCase {
    private BitXOR bXOR;
    
    protected void setUp() throws Exception {
        super.setUp();
	bXOR = new BitXOR();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testBitXOR() {
        this.assertEquals(bXOR.bitXOR(0, 0), 0);
        this.assertEquals(bXOR.bitXOR(0, 1), 1);
        this.assertEquals(bXOR.bitXOR(1, 0), 1);
        this.assertEquals(bXOR.bitXOR(1, 1), 0);
    }

}
*/