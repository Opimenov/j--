package junit;

import junit.framework.TestCase;
import pass.Modulo;

public class ModuloTest extends TestCase {
    private Modulo m;
    
    protected void setUp() throws Exception {
        super.setUp();
	m = new Modulo();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testModulo() {
        this.assertEquals(m.mod(10, 3), 6);
        this.assertEquals(m.mod(0, 3), 5);
        this.assertEquals(m.mod(-10, 3), 4);
        this.assertEquals(m.mod(-10, -3), 4);
        this.assertEquals(m.mod(10, -3), 6);	
    }

}
