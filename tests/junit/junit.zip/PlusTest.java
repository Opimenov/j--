package junit;

import junit.framework.TestCase;
import pass.Plus;

public class PlusTest extends TestCase {
    private Plus plus;
    
    protected void setUp() throws Exception {
        super.setUp();
	plus = new Plus();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testPlus() {
        this.assertEquals(plus.add2Nums(6, 5), 11);
        this.assertEquals(plus.add2Nums(6, -5), 1);
    }

}
