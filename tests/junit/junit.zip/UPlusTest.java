package junit;

import junit.framework.TestCase;
import pass.UPlus;

public class UPlusTest extends TestCase {
    private UPlus uPlus;
    
    protected void setUp() throws Exception {
        super.setUp();
	uPlus = new UPlus();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testUPlus() {
        this.assertEquals(uPlus.isInt(6), 6);
	this.assertEquals(uPlus.isInt(-6), -6);
	this.assertEquals(uPlus.isInt(0), 0);		
    }

}
