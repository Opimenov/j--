//package pass;
//
//public class BitAND {
//    public int bitAND(int x, int y) {
//	return x & y;
//    }
//}
