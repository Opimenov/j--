//package pass;
//
//public class BitOR {
//    public int bitOR(int x, int y) {
//	return x | y;
//    }
//}
