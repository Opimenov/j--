//package pass;
//
//public class BitXOR {
//    public int bitXOR(int x, int y) {
//	return x ^ y;
//    }
//}
