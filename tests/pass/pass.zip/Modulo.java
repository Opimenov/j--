package pass;
//import java.lang.System;
public class Modulo {
    public int mod(int x, int y) {
	return 5 + x % y;
    }
    //    public static void main(String[] args) {
    //	System.out.println(mod(10,3));
    //    }
}
