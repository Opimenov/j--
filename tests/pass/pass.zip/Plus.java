package pass;

public class Plus {
    public int add2Nums(int x, int y) {
	return x + y;
    }
}
