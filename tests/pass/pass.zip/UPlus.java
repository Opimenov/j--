package pass;

public class UPlus {
    public int isInt(int x) {
	return +x;
    }
}
